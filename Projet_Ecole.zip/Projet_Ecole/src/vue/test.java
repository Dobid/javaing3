package vue;
import java.sql.SQLException;

import projet_ecole.*;
public class test { 


	 public static void main(String[] args) throws ClassNotFoundException, SQLException {
		 Database bdd=new Database();
		
//	new modifier_supprimer_eleve();
		new Fenetre2();
			
		//new modifier_supprimer_prof();
			
			}
	 
 }